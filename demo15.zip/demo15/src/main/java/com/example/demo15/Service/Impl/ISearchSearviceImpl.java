package com.example.demo15.Service.Impl;

import com.example.demo15.Model.Bean;
import com.example.demo15.Service.ISearchService;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
@Service("searchService")
public class ISearchSearviceImpl implements ISearchService {
    private final String basePath = "F:/test/books/";//文件储存根路径
    private String name="";
    private String userID="001";

    @Override
    public List<Bean> search(String name) {
        List<Bean> list = new ArrayList<>();
        File parFile = new File(basePath);
        if(!parFile.exists())
            return null;
        for(File file : parFile.listFiles()){
            if(file.isDirectory()){
                list.addAll(searchFile(file,name));
            }
        }
        return list;
    }
    private List<Bean> searchFile(File parDir,String name){
        List<Bean> list = new ArrayList<>();
        for(File file : parDir.listFiles()){
            if(file.getName().contains(name)){
                list.add(new Bean(file.getName(),file.getAbsolutePath()));
            }
        }
        return list;
    }
}
