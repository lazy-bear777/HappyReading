package com.example.demo15.Service;

import com.example.demo15.Model.Bean;

import java.util.List;

public interface ISearchService {
        List<Bean> search(String name);
}
