package com.example.demo15.Service.Impl;

import com.example.demo15.Service.IFileService;
import org.springframework.stereotype.Service;

import javax.xml.crypto.Data;
import java.io.*;
@Service("IFileService")
public class IFileServiceImpl implements IFileService {
    private final String basePath = "F:/test/books/";//文件储存根路径
    private String name="";
    private String userID="001";
    /**
     * 存文件
     * @param inputStream
     * @param fileName
     * @return
     */
    @Override
    public String saveFile(InputStream inputStream,String fileName) {
        DataInputStream dis = new DataInputStream(inputStream);
        File file = new File(basePath+userID,fileName);
        if(!file.exists()){
            try {
                System.out.println(file.getAbsolutePath());
                 file.createNewFile();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        FileOutputStream fps = null;
        try {
            fps = new FileOutputStream(file);
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];
        int length = -1;

        try {
            while ((length=dis.read(buffer))!=-1){
                fps.write(buffer,0,length);
            }
            fps.flush();
            fps.close();
            dis.close();
            inputStream.close();
        }catch (IOException e){
            e.printStackTrace();
        }

        return "上传成功！";
    }

    /**
     * 根据文件名上传文件
     * @param outputStream
     * @param fileName
     * @return
     */
    @Override
    public String uploadFile(OutputStream outputStream, String fileName) {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
        File file = new File(basePath);
        for(String filen: file.list()){
            if(filen.equals(fileName)){
                name = filen;
                break;
            }
        }
        file = new File(basePath,name);
        return loadFile(dataOutputStream, file);
    }

    /**
     * 根据路径上传文件
     * @param outputStream
     * @param path
     * @return
     */
    @Override
    public String upload(OutputStream outputStream, String path) {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
        File file = new File(path);
        return loadFile(dataOutputStream, file);
    }

    private String loadFile(DataOutputStream dataOutputStream, File file) {
        if(file.exists()){
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                int bufferSize = 1024;
                byte[] bytes = new byte[bufferSize];
                int len = -1;
                while ((len=fileInputStream.read(bytes))!=-1){
                    dataOutputStream.write(bytes,0,len);
                }
                dataOutputStream.flush();
                fileInputStream.close();
                dataOutputStream.close();

                return "下载成功！";
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return "无法找到该资源！";
    }

    @Override
    public String getFileName() {
        return name;
    }
}
