package com.example.demo15.Controler;

import com.example.demo15.Common.ServerResponse;
import com.example.demo15.Model.Bean;
import com.example.demo15.Service.IFileService;
import com.example.demo15.Service.ISearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;

@Controller
public class FileController {
    @Autowired
    IFileService fileService;
    @Autowired
    ISearchService searchService;
    @RequestMapping(value = "/uploadBook")
    public void upLoadFile(HttpServletRequest request, HttpServletResponse response){
        try {
            String result = "";
            try {
                result = fileService.saveFile(request.getInputStream(), URLDecoder.decode(request.getHeader("fileName"),"utf-8"));
            }catch (Exception e){
                e.printStackTrace();
                result = "上传失败";
            }
            request.getSession().invalidate();
            response.setContentType("text/html;charset=UTF-8");
            ObjectOutputStream dos = new ObjectOutputStream(response.getOutputStream());
            dos.writeObject(result);
            dos.flush();
            dos.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @RequestMapping(value = "/downloadBook")
    public void DownloadFile(HttpServletRequest request, HttpServletResponse response){
            try {
                fileService.uploadFile(response.getOutputStream(), URLDecoder.decode(request.getHeader("fileName"),"utf-8"));
                response.setHeader("fileName",URLEncoder.encode(fileService.getFileName(),"utf-8"));
                System.out.println(fileService.getFileName());
            }catch (Exception e){
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream");
    }

    /**
     * 查找小说
     * @param bookName 小说名
     * @return
     */
    @RequestMapping(value = "/search")
    @ResponseBody
    public ServerResponse<List<Bean>> search(String bookName){
        try {
            List<Bean> list;
            list = searchService.search(bookName);
            return ServerResponse.createSuccessData(list);
        }catch (Exception e){
            e.printStackTrace();
        }
        return ServerResponse.createErrorMessage("文件查找失败！");
    }
}
