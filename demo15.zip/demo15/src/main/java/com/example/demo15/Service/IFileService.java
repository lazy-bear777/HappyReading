package com.example.demo15.Service;
import java.io.InputStream;
import java.io.OutputStream;

public interface IFileService {
    String saveFile(InputStream inputStream, String fileName);
    String uploadFile(OutputStream outputStream, String fileName);
    String upload(OutputStream outputStream,String path);
    String getFileName();
}
