package com.bifan.txtreaderlib.interfaces;

/**
 * created by ： bifan-wei
 */

public interface IPageEdgeListener {
    void onCurrentFirstPage();
    void onCurrentLastPage();
}
