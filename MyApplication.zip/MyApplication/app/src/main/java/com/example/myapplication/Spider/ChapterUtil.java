package com.example.myapplication.Spider;

import java.util.ArrayList;
import java.util.List;

public class ChapterUtil {
    public static List<Chapter> getChapter(){
        return new ArrayList<>();
    }
    public static List<Chapter> getChapters(){
        return new ArrayList<>();
    }
}
