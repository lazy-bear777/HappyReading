package com.example.myapplication.Common;

public class Soure {
    private String soureName;

    public Soure(String soureName){
        this.soureName=soureName;

    }
    public String getSoureName()
    {
        return soureName;
    }

}
