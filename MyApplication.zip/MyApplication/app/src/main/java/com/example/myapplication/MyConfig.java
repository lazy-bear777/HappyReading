package com.example.myapplication;

public class MyConfig {
    public static final String url = "http://47.102.205.169:8080/";
}
